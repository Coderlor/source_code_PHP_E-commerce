<?php

use SCart\Core\DB\migrations\PrepareTablesAdmin;
class CreateTablesAdmin extends PrepareTablesAdmin
{
    //
}
