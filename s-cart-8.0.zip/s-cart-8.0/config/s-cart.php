<?php
return [
    'version'     => '8.0',
    'sub-version' => '8.0.0',
    'type'        => 'basic',
    'homepage'    => 'https://s-cart.org',
    'title'       => 'Free Open Source eCommerce for Business',
];
