<?php
    $this->loadTranslationsFrom(__DIR__.'/Lang', 'Plugins/Other/GoogleCaptcha');
    $this->loadViewsFrom(__DIR__.'/Views', 'Plugins/Other/GoogleCaptcha');
    // $this->mergeConfigFrom(
    //     __DIR__.'/config.php', 'key_define_for_plugin'
    // );