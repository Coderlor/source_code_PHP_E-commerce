<?php
return [
    'title'       => 'Google reCaptcha',
    'secrect_key' => 'Secrect key',
    'site_key'    => 'Site key',
    'admin'      => [
        'title'          => 'GoogleCaptcha',
    ],
];
