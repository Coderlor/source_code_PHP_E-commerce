<?php

return [
    'title'         => 'Vận chuyển cơ bản',
    'id'            => 'ID',
    'shipping_free' => 'Đơn hàng miễn phí ship',
    'fee'           => 'Phí vận chuyển',
    'sort'          => 'Thứ tự',
    'add_more'      => 'Thêm mới',
    'remove'        => 'Xóa',
];
