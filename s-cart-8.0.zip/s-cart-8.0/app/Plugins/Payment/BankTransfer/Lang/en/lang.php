<?php

return [
    'title' => 'Bank transfer',
    'info' => 'Bank infomation',
];
